package com.example.periodapp.Connection;

public class Connection {
    public static String ip = "34.27.253.118";
    public static String username = "root";
    public static String password = "Triplets0730$";
    public static String db = "userinfo";
}
