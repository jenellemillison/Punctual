package com.example.periodapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class ResultsActivity extends AppCompatActivity {

    Button home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // below line is used to get the
        // instance of our Firebase database.

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        home = findViewById(R.id.home);
        home.setEnabled(true);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ResultsActivity.this, HomePageActivity.class));
            }
        });
    }
}