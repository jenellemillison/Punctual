/* FIREBASE CODE

 */

package com.example.periodapp.ui.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.periodapp.HomePageActivity;
import com.example.periodapp.databinding.ActivityRegisterBinding;
import com.example.periodapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterActivity extends AppCompatActivity {

    // creating a variable for our
    // Firebase Database.
    FirebaseDatabase firebaseDatabase;

    // creating a variable for our Database
    // Reference for Firebase.
    DatabaseReference databaseReference;

    // creating a variable for
    // our object class
    UserInfo userInfo;

    // creating variables for
    // EditText and buttons.
    EditText name, username, password;
    Button register, signin;

    RegisterViewModel registerViewModel;
    ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        registerViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(RegisterViewModel.class);


        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final Button loginButton = binding.register;
        final ProgressBar loadingProgressBar = binding.loading;

        // initializing our edittext and button
        name = (EditText) findViewById(R.id.name);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        register = findViewById(R.id.register);
        signin = findViewById(R.id.signin);
        System.out.println(register);
        System.out.println(name);


        // below line is used to get the
        // instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();

        // below line is used to get reference for our database.
        databaseReference = firebaseDatabase.getReference("UserInfo");

        // initializing our object
        // class variable.
        userInfo = new UserInfo();


        registerViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        registerViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                }
                setResult(Activity.RESULT_OK);

                //Complete and destroy login activity once successful
                finish();
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                registerViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    registerViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());
                }
                return false;
            }
        });

        signin.setEnabled(true);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, SignInActivity.class));
            }
        });


        // adding on click listener for our button.
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("SIGN IN HAS BEEN CLICKED!");

                // getting text from our edittext fields.
                String nameDB = name.getText().toString();
                String usernameDB = username.getText().toString();
                String passwordDB = password.getText().toString();



                // below line is for checking whether the
                // edittext fields are empty or not.
                if (TextUtils.isEmpty(nameDB) && TextUtils.isEmpty(usernameDB) && TextUtils.isEmpty(passwordDB)) {
                    // if the text fields are empty
                    // then show the below message.
                    Toast.makeText(RegisterActivity.this, "Please add some data.", Toast.LENGTH_SHORT).show();
                } else {
                    // else call the method to add
                    // data to our database.
                    addDatatoFirebase(nameDB, usernameDB, passwordDB);
                    startActivity(new Intent(RegisterActivity.this, HomePageActivity.class));
                }
            }
        });
    }

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    private void addDatatoFirebase(String name, String user, String password) {
        // below 3 lines of code is used to set
        // data in our object class.
        userInfo.setName(name);
        userInfo.setUsername(user);
        userInfo.setPassword(password);

        // we are use add value event listener method
        // which is called with database reference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // inside the method of on Data change we are setting
                // our object class to our database reference.
                // data base reference will sends data to firebase.
                databaseReference.setValue(userInfo);

                // after adding this data we are showing toast message.
                Toast.makeText(RegisterActivity.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.
                Toast.makeText(RegisterActivity.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }
}





//MYSQL ATTEMPT
/*
package com.example.periodapp.ui.login;


import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.periodapp.Connection.Connection;
import com.example.periodapp.R;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.periodapp.databinding.ActivityRegisterBinding;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kotlin.text.UStringsKt;

public class RegisterActivity extends AppCompatActivity {

    EditText name, username, password;
    Button registerbtn;
    TextView sql_status;

    java.sql.Connection con;

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = (EditText) findViewById(R.id.name);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        registerbtn = (Button) findViewById(R.id.login);
        sql_status = (TextView) findViewById(R.id.sql_status);

        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        String server = Connection.ip.toString();
        String database = Connection.db.toString();
        String username = Connection.username.toString();
        String password = Connection.password.toString();

        Connection connection = null;
        String connectionURL = null;
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            connectionURL = "jdbc.jtds:sqlserver://" + server + "/" + database + ";user=" + username + ";password" + password + ";";
            connection = (Connection) DriverManager.getConnection(connectionURL);
            sql_status.setText("CONNECTED");
        } catch (Exception e) {
            Log.e("ERROR: SQL CONNECTION FAILED", e.getMessage());
        }
        ;

    }


    // THIS IS ON BUTTON PRESS TO INSERT INTO DB - NEED TO FIX
     public class registeruser {
        Runnable task = () -> {
            try {
                sql_status.setText("IN REGISTERUSER");
            } catch (Exception e) {

            }
        };

        //public class registeruser implements Runnable{
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Runnable runnableTask = () -> {
            try {
                con = (java.sql.Connection) connectionClass(Connection.username.toString(), Connection.password.toString(), Connection.db.toString(), Connection.ip.toString());
                if (con == null) {
                    //fail - check your internet connection
                } else {

                    String sql = "INSERT INTO register(userID, username, password) VALUES('" + username.getText() + "', '" + name.getText() + "', '" + password.getText() + "')";
                    Statement stmt = con.createStatement();
                    stmt.execute(sql);
                    sql_status.setText("YOU MADE IT");
                }
            } catch (Exception e) {
            }
            ;
        };
    }

    @SuppressLint({"NewApi", "LongLogTag"})
    public Connection connectionClass(String username, String password, String database, String server) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String connectionURL = null;
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            connectionURL = "jdbc.jtds:sqlserver://" + server + "/" + database + ";user=" + username + ";password" + password + ";";
            connection = (Connection) DriverManager.getConnection(connectionURL);
        } catch (Exception e) {
            Log.e("ERROR: SQL CONNECTION FAILED", e.getMessage());
        }
        ;

        return connection;
    }

        /*
        executor.execute(new Runnable() {
           @Override
           public void run(){

            }
        });
        */




    // AsyncTask is depricated, use Executors from java.util.concurrent
    /*
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler handler = new Handler(Looper.getMainLooper());

    executor.execute(() -> {
       handler.post(() -> {

       });
    });
    */

    /*
    public class registeruser extends AsyncTask<String, String, String> {

        String z = "";
        Boolean isSuccess = false;

        @Override
        protected Object doInBackground(Object[] objects) {
            return null;
        }

        public registeruser() {
            super();
        }

        @Override
        protected void onPreExecute() {
            sql_status.setText("Registering User...");
        }

        @Override
        protected void onPostExecute(Object o) {
            sql_status.setText("Registration Successful!");
            name.setText("");
            username.setText("");
            password.setText("");
        }
    }

     */





    /*
    private AppBarConfiguration mAppBarConfiguration;
    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarRegister.toolbar);
        binding.appBarRegister.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_register);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.register, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_register);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
     */
//}
//*/
