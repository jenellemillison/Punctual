package com.example.periodapp;

import android.content.Intent;
import android.os.Bundle;

import com.example.periodapp.ui.login.RegisterActivity;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.periodapp.databinding.ActivityHomePageBinding;

public class HomePageActivity extends AppCompatActivity {

    Button nav_cal;
    Button nav_about;
    Button nav_map;
    Button nav_impact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_page);

        nav_cal = findViewById(R.id.nav_cal);
        nav_about = findViewById(R.id.nav_about);
        nav_map = findViewById(R.id.nav_map);
        nav_impact = findViewById(R.id.nav_impact);

        nav_cal.setEnabled(true);
        nav_about.setEnabled(true);
        nav_map.setEnabled(true);
        nav_impact.setEnabled(true);

        nav_cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePageActivity.this, CalendarActivity.class));
            }
        });

        nav_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePageActivity.this, AboutActivity.class));
            }
        });

        nav_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePageActivity.this, MapActivity.class));
            }
        });

        nav_impact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePageActivity.this, SurveyActivity.class));
            }
        });

    }

}