package com.example.periodapp;

import static java.lang.String.valueOf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import org.json.*;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;
    SupportMapFragment mapFragment;
    SearchView searchView;
    CountDownLatch countDownLatch = new CountDownLatch(1);
    Button home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        searchView = findViewById(R.id.sv_location);
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.google_map);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            OkHttpClient client = new OkHttpClient();
            MediaType JSON = MediaType.parse("application/json; charset=utf-8");
            public Call get(String url, String json, Callback callback) {
                RequestBody body = RequestBody.create(JSON, json);
                Request request = new Request.Builder()
                        .url(url)
                        .build();
                Call call = client.newCall(request);
                call.enqueue(callback);
                return call;
            }

            @Override
            public boolean onQueryTextSubmit(String s) {
                //System.out.println("PLS WORKIES");
                Hashtable<String, LatLng> locsMap = new Hashtable<String, LatLng>();
                String location = searchView.getQuery().toString();
                List<Address> addressList = null;
                MarkerOptions options = new MarkerOptions();

                if (location != null || !location.equals("")) {
                    Geocoder geocoder = new Geocoder(MapActivity.this);
                    try {
                        addressList = geocoder.getFromLocationName(location, 1);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Address address = addressList.get(0);
                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                    String placesURL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?keyword=womens+health+center&location=" +
                            latLng.latitude + "," + latLng.longitude + "&radius=1000&key=AIzaSyB6rkXsI4lzRwHzqY_hp2SFIFZdu8BmeO4";

                    get(placesURL, "", new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            System.out.println("EHEHEHE");
                            countDownLatch.countDown();

                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            if (response.isSuccessful()) {
                                String responseStr = response.body().string();
                                //System.out.println(responseStr);
                                JSONObject obj = null;
                                try {
                                    obj = new JSONObject(responseStr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    System.out.println("RUH ROH");
                                }
                                System.out.println("STARTIES");
                                try {
                                    JSONArray arr = obj.getJSONArray("results");
                                    System.out.println("LENGTH" + arr.length());
                                    String locationName = null;
                                    String locationLat= null;
                                    String locationLng= null;
                                    for (int i = 0; i < arr.length(); i++)
                                    {
                                        //System.out.println("LENGTH" + arr.length());
                                        locationName = arr.getJSONObject(i).getString("name");
                                        locationLat = arr.getJSONObject(i).getJSONObject("geometry").getJSONObject("location").getString("lat");
                                        locationLng = arr.getJSONObject(i).getJSONObject("geometry").getJSONObject("location").getString("lng");
                                        LatLng latLngPlace = new LatLng(Double.parseDouble(locationLat), Double.parseDouble(locationLng));
                                        //System.out.println("LAT " + locationLat);
                                        //System.out.println("LNG " + locationLng);
                                        locsMap.put(locationName, latLngPlace);


                                    }
                                    System.out.println("AYO " + locsMap);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    System.out.println("OOPSIE");
                                    System.out.println(responseStr);
                                }
                                System.out.println("AHHHHHHHHHH");

                            } else {
                                System.out.println("NOOOOOOOOO");
                                String responseStr = response.body().string();
                                System.out.println(responseStr);

                            }
                            countDownLatch.countDown();
                        }
                    });

                    /*
                    for (Map.Entry<String, LatLng> element : locsMap.entrySet()) {
                        String locName = element.getKey();
                        LatLng latLng2 = element.getValue();
                        options.position(latLng2);
                        options.title(locName);
                        System.out.println("COORDS: " + latLng2);
                        map.addMarker(options);
                        //map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng2, 10));
                    }
                    */
                    try {
                        countDownLatch.await();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("OYA " + locsMap);
                    populateMap(map, locsMap);
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        mapFragment.getMapAsync(this);


        home = findViewById(R.id.home);
        home.setEnabled(true);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MapActivity.this, HomePageActivity.class));
            }
        });
    }

    public void populateMap(GoogleMap map, Hashtable<String, LatLng> hashies) {
        GoogleMap new_map = map;
        System.out.println("TABLEEE " + hashies);
        System.out.println(hashies.size());
        for (Map.Entry<String, LatLng> element : hashies.entrySet()) {
            String locName = element.getKey();
            LatLng latLng = element.getValue();
            System.out.println("MEH" + latLng);
            new_map.addMarker(new MarkerOptions().position(latLng).title(locName));
        }

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
    }
}